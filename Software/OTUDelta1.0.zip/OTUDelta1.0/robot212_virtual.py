#!/usr/bin/python
"""
Virtual Delta Bot

Daniel J. Gonzalez - dgonz@mit.edu
2.12 Intro to Robotics Spring 2019
"""
from numpy import pi
def trajMoveRad(posDesired = (0, 0, 0), velDesired = 2*pi/8, accDesired = 2*pi/8):
    return